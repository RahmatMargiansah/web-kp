<!DOCTYPE html>
<html>
<head>
	<title>Laporan</title>
</head>
<body>
	
	<h2 style="text-align: center">Laporan Detail <?php echo e($teknisi->name); ?> Nik <?php echo e($teknisi->nik); ?></h2>
		
	<center>
	<img src="<?php echo e(('storage/photo/'.$teknisi->image)); ?>" width="500px">
	</center>



	<table border="1" style="border-collapse: collapse; margin: auto">
		<thead>
		<tr>
			<th>Nik</th>
			<th>Nama</th>
			<th>Tipe Work Order</th>
			<th>Kategory</th>
			<th>Action</th>
			<th>No Spbu</th>
			<th>Alamat Spbu</th>
			<th>Tanggal Laporan</th>
			<th>Keterangan</th>
		</tr>
		</thead>
		<tbody>
		<tr>
			<td><?php echo e($teknisi->nik); ?></td>
	  		<td><?php echo e($teknisi->name); ?></td>
	  		<td><?php echo e($teknisi->wo); ?></td>
	  		<td><?php echo e($teknisi->kategory); ?></td>
	  		<td><?php echo e($teknisi->action); ?></td>
	  		<td><?php echo e($teknisi->spbu); ?></td>
		  	<td><?php echo e($teknisi->alamat_spbu); ?></td>
		  	<td><?php echo e($teknisi->tanggal_laporan); ?></td>
			<td><?php echo e($teknisi->keterangan); ?></td>
		</tr>
		</tbody>
	</table>
</div>
</body>
</html><?php /**PATH C:\xampp\htdocs\webreport\resources\views/pdf/laporan.blade.php ENDPATH**/ ?>