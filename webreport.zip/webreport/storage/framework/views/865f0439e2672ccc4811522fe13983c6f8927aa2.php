

<?php $__env->startSection('tittle'); ?>

<?php $__env->startSection('content'); ?>

<h4>Data Laporan</h4>
		<div class="my-5">
					<div class="my-3 col-12 col-sm-8 col-md-5">
						<form action="" method="get">
						  <div class="input-group mb-3">
    			            <input type="text" class="form-control" name="keyword" placeholder="Search">
    			            <button class="input-group-text btn btn-primary">Search</button>
						  </div>
						</form>
					</div>
				</div>

				<form method="GET" action="/filter">
					<div class="row pb-3">
						<div class="col-md-3">
							<label>Dari tanggal: </label>
							<input type="date" name="start_date" class="form-control">
						</div>
						<div class="col-md-3">
							<label>Sampai tanggal: </label>
							<input type="date" name="end_date" class="form-control">
						</div>
						<div class="col-md-1 pt-4">
							<button type="submit" class="btn btn-primary">Filter</button>
						</div>
					</div>
				</form>
		
			<div class="container">
				<?php if(Session::has('status')): ?>
					<div class="alert alert-success" role="alert">
						<?php echo e(Session::get('message')); ?>

					</div>
				<?php endif; ?>
				<div class="my-3 d-flex justify-content-end">
					<a href="/export-pdf" class="btn btn-secondary">Print Laporan</a>
				</div>
				  <table class="table table-striped">
				  	<tr>
				  		<th>No</th>
				  		<th>Nik</th>
				  		<th>Nama</th>
				  		<th>Tipe Work Order</th>
				  		<th>Kategory</th>
				  		<th>Action</th>
				  		<th>No Spbu</th>
				  		<th>Alamat Spbu</th>
				  		<th>Tanggal Laporan</th>
				  		<th>Keterangan</th>
				  		<th>Eviden Laporan</th>
				  		<th>Action</th>
				  	</tr>
				  			<?php $__currentLoopData = $teknisiList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				  	<tr>
				  			<td><?php echo e($loop->iteration); ?></td>
				  			<td><?php echo e($data->nik); ?></td>
				  			<td><?php echo e($data->name); ?></td>
				  			<td><?php echo e($data->wo); ?></td>
				  			<td><?php echo e($data->kategory); ?></td>
				  			<td><?php echo e($data->action); ?></td>
				  			<td><?php echo e($data->spbu); ?></td>
				  			<td><?php echo e($data->alamat_spbu); ?></td>
				  			<td><?php echo e($data->tanggal_laporan); ?></td>
				  			<td><?php echo e($data->keterangan); ?></td>
				  			<td>
				  			<div class="my-3">
				  				<img src="<?php echo e(asset('storage/photo/'.$data->image)); ?>" width="50px">
				  			</div>
				  			</td>
				  			<td>
				  				<a href="/managerviewdetaillaporan/<?php echo e($data->id); ?>" class="btn btn-primary">Detail Laporan</a>
				  			</td>
				  	</tr>
				  			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				  </table>	

				  <div class="my-5">
				  	<?php echo e($teknisiList->withQueryString()->links()); ?>

				  </div>
			</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.managermainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webreport\resources\views/manager.blade.php ENDPATH**/ ?>