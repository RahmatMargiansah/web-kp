

<?php $__env->startSection('tittle'); ?>

<?php $__env->startSection('content'); ?>

	<h1></h1>
	<h2>Selamat Datang,</h2>
	<h3>Anda adalah <?php echo e(Auth::user()->name); ?></h3>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webreport\resources\views\home.blade.php ENDPATH**/ ?>