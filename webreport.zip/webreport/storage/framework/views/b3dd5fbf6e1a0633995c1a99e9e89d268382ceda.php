

<?php $__env->startSection('tittle'); ?>

<?php $__env->startSection('content'); ?>

	<div class="mt-5">
			<h2>Yakin ingin menghapus data : <?php echo e($teknisi->nik); ?>, <?php echo e($teknisi->name); ?>, <?php echo e($teknisi->wo); ?>, <?php echo e($teknisi->spbu); ?>, <?php echo e($teknisi->nik); ?>, <?php echo e($teknisi->tanggal_laporan); ?></h2>

		<form style="display: inline-block" action="/teknisi-destroy/<?php echo e($teknisi->id); ?>" method="post">
			<?php echo csrf_field(); ?>
			<?php echo method_field('delete'); ?>
			<button class="btn btn-danger">Hapus</button>
		</form>

			<a href="/teknisi" class="btn btn-primary">Batal</a>
	</div>


<?php $__env->stopSection(); ?>


	

<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webreport\resources\views\teknisi-delete.blade.php ENDPATH**/ ?>