

<?php $__env->startSection('tittle'); ?>

<?php $__env->startSection('content'); ?>

	<div class="container">
	  	<div class="mt-5 col-8 m-auto">
	  		<form action="/teknisi/<?php echo e($teknisi->id); ?>" method="POST">
	  			<?php echo csrf_field(); ?>
	  			<?php echo method_field('PUT'); ?>
	  			<div class="mb-3">
	  				<label for="nik">Nik</label>
	  				<input type="text" class="form-control" name="nik" id="nik" value="<?php echo e($teknisi->nik); ?>" required>
	  			</div>
	  			<div class="mb-3">
	  				<label for="name">Nama</label>
	  				<input type="text" class="form-control" name="name" id="name" value="<?php echo e($teknisi->name); ?>" required>
	  			</div>
	  			<div class="mb-3">
	  				<label for="type">Tipe Work Order</label>
	  				<select name="wo" id="type" class="form-control" required>
	  					<option value="<?php echo e($teknisi->wo); ?>"><?php echo e($teknisi->wo); ?></option>
	  					<?php if($teknisi->wo == 'Gangguan'): ?>
	  						<option value="Maintenance">Maintenance</option>
	  					<?php else: ?>
	  						<option value="Gangguan">Gangguan</option>
	  					<?php endif; ?>
	  				</select>
	  			</div>
	  			<div class="mb-3">
	  				<label for="spbu">No Spbu</label>
	  				<input type="text" class="form-control" name="spbu" id="spbu" value="<?php echo e($teknisi->spbu); ?>" required>
	  			</div>
	  			<div class="mb-3">
	  				<label for="alamat">Alamat Spbu</label>
	  				<input type="text" class="form-control" name="alamat_spbu" id="alamat" value="<?php echo e($teknisi->alamat_spbu); ?>" required>
	  			</div>
	  			<div class="mb-3">
	  				<label for="tanggal">Tanggal Laporan</label>
	  				<input type="date" class="form-control" name="tanggal_laporan" id="tanggal" value="<?php echo e($teknisi->tanggal_laporan); ?>" required>
	  			</div>
	  			<div class="mb-3">
	  				<label for="keterangan">Keterangan</label>
	  				<input type="text" class="form-control" name="keterangan" id="keterangan" value="<?php echo e($teknisi->keterangan); ?>" required>
	  			</div>
	  			<div class="mb-3">
	  				<button class="btn btn-primary">Update</button>
	  			</div>
	  		</form>
	  	</div>
	  </div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webreport\resources\views\teknisi-edits.blade.php ENDPATH**/ ?>