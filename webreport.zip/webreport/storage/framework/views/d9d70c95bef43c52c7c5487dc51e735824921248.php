

<?php $__env->startSection('tittle'); ?>

<?php $__env->startSection('content'); ?>

<div class="my-3 d-flex justify-content-center">
	<h2>Halaman Detail <?php echo e($teknisi->name); ?> Nik <?php echo e($teknisi->nik); ?></h2>
</div>
		<?php echo csrf_field(); ?>

<div class="my-3 d-flex justify-content-center">
	<img src="<?php echo e(asset('storage/photo/'.$teknisi->image)); ?>" alt="" width="500px">
</div>
				

<div class="box">
	<div class="my-3 d-flex justify-content-center">
		<a href="/export-pdf/<?php echo e($teknisi->id); ?>" class="btn btn-secondary">Print</a>
	</div>
	<table class="table table-striped">
		<tr>
			<th>Nik</th>
			<th>Nama</th>
			<th>Tipe Work Order</th>
			<th>No Spbu</th>
			<th>Alamat Spbu</th>
			<th>Tanggal Laporan</th>
			<th>Keterangan</th>
		</tr>
		<tr>
			<td><?php echo e($teknisi->nik); ?></td>
	  		<td><?php echo e($teknisi->name); ?></td>
	  		<td><?php echo e($teknisi->wo); ?></td>
	  		<td><?php echo e($teknisi->spbu); ?></td>
		  	<td><?php echo e($teknisi->alamat_spbu); ?></td>
		  	<td><?php echo e($teknisi->tanggal_laporan); ?></td>
			<td><?php echo e($teknisi->keterangan); ?></td>
		</tr>
	</table>
	
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminmainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webreport\resources\views/viewdetaillaporan.blade.php ENDPATH**/ ?>