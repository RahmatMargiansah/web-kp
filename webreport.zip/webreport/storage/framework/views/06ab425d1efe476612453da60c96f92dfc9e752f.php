

<?php $__env->startSection('tittle'); ?>

<?php $__env->startSection('content'); ?>


	<div class="container">
		<h4>Data Laporan</h4>
			<div class="container">
				<div class="my-5">
				  <a href="teknisi-add" class="btn btn-primary">Add Data</a>
				</div>
				<table class="table table-striped">
				  	<tr>
				  		<th>No</th>
				  		<th>Nik</th>
				  		<th>Nama</th>
				  		<th>Tipe Work Order</th>
				  		<th>No Spbu</th>
				  		<th>Alamat Spbu</th>
				  		<th>Tanggal Laporan</th>
				  		<th>Keterangan</th>
				  		<th>Eviden Laporan</th>
				  		<th>Action</th>
				  	</tr>
				</table>
			</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webreport\resources\views\user.blade.php ENDPATH**/ ?>