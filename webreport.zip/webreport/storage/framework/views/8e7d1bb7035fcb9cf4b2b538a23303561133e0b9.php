

<?php $__env->startSection('tittle'); ?>

<?php $__env->startSection('content'); ?>

	<div class="container">
		<h4>Data Laporan</h4>
			<div class="container">
				<div class="my-5">
				  <a href="teknisi-add" class="btn btn-primary">TAMBAH LAPORAN</a>
				</div>

				<?php if(Session::has('status')): ?>
					<div class="alert alert-success" role="alert">
						<?php echo e(Session::get('message')); ?>

					</div>
				<?php endif; ?>

				  <table class="table table-striped">
				  	<tr>
				  		<th>No</th>
				  		<th>Nik</th>
				  		<th>Nama</th>
				  		<th>Tipe Work Order</th>
				  		<th>Kategory</th>
				  		<th>Action</th>
				  		<th>No Spbu</th>
				  		<th>Alamat Spbu</th>
				  		<th>Tanggal Laporan</th>
				  		<th>Keterangan</th>
				  		<th>Eviden Laporan</th>
				  		<th>Action</th>
				  	</tr>
				  			<?php $__currentLoopData = $teknisiList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				  	<tr>
				  		<td><?php echo e($loop->iteration); ?></td>
				  		<td><?php echo e($data->nik); ?></td>
				  		<td><?php echo e($data->name); ?></td>
				  		<td><?php echo e($data->wo); ?></td>
				  		<td><?php echo e($data->kategory); ?></td>
				  		<td><?php echo e($data->action); ?></td>
				  		<td><?php echo e($data->spbu); ?></td>
				  		<td><?php echo e($data->alamat_spbu); ?></td>
				  		<td><?php echo e($data->tanggal_laporan); ?></td>
				  		<td><?php echo e($data->keterangan); ?></td>
				  		<td>
				  		<div class="my-3">
				  			<img src="<?php echo e(asset('storage/photo/'.$data->image)); ?>" width="50px">
				  </div>
				  		</td>
				  		<td>
				  			<a href="teknisi-edits/<?php echo e($data->id); ?>" class="btn btn-success">Edit</a>
				  			<a href="teknisi-delete/<?php echo e($data->id); ?>" class="btn btn-danger">Delete</a>
				  		</td>
				  </tr>
				  			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				  </table>	

				  <div class="my-5">
				  	<?php echo e($teknisiList->links()); ?>

				  </div>
			</div>
	</div>

<?php $__env->stopSection(); ?>

	
<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webreport\resources\views/teknisi.blade.php ENDPATH**/ ?>