<!DOCTYPE html>
<html>
<head>
	<title>All Laporan</title>
</head>
<body>
	<h2 style="text-align: center">Laporan Teknisi Jakarta Selatan</h2>

			<table border="1" style="border-collapse: collapse; margin: auto">
					<thead>
				  	<tr>
				  		<th>No</th>
				  		<th>Nik</th>
				  		<th>Nama</th>
				  		<th>Tipe Work Order</th>
				  		<th>Kategory</th>
				  		<th>Action</th>
				  		<th>No Spbu</th>
				  		<th>Alamat Spbu</th>
				  		<th>Tanggal Laporan</th>
				  		<th>Keterangan</th>
				  		<th>Eviden Laporan</th>
				  	</tr>
				  	</thead>
				  	<tbody>
				  		<?php $__currentLoopData = $teknisiList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				  	<tr>
				  		<td><?php echo e($loop->iteration); ?></td>
				  		<td><?php echo e($data->nik); ?></td>
				  		<td><?php echo e($data->name); ?></td>
				  		<td><?php echo e($data->wo); ?></td>
				  		<td><?php echo e($data->kategory); ?></td>
				  		<td><?php echo e($data->action); ?></td>
				  		<td><?php echo e($data->spbu); ?></td>
				  		<td><?php echo e($data->alamat_spbu); ?></td>
				  		<td><?php echo e($data->tanggal_laporan); ?></td>
				  		<td><?php echo e($data->keterangan); ?></td>
				  		<td>
				  			<center>
				  				<img src="<?php echo e(('storage/photo/'.$data->image)); ?>" width="120px">
				  			</center>
				  		</td>
				  	</tr>
				  		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				  	</tbody>
			</table>
</body>
</html><?php /**PATH C:\xampp\htdocs\webreport\resources\views/pdf/alllaporan.blade.php ENDPATH**/ ?>