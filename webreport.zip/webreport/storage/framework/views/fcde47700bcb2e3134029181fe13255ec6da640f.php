

<?php $__env->startSection('tittle'); ?>

<?php $__env->startSection('content'); ?>

	<div class="container">
	  	<div class="mt-5 col-8 m-auto">
	  		<form action="teknisi" method="post" enctype="multipart/form-data">
	  			<?php echo csrf_field(); ?>
	  			<div class="mb-3">
	  				<label for="nik">Nik</label>
	  				<input type="text" class="form-control" name="nik" id="nik" required>
	  			</div>
	  			<div class="mb-3">
	  				<label for="name">Nama</label>
	  				<input type="text" class="form-control" name="name" id="name" required>
	  			</div>
	  			<div class="mb-3">
	  				<label for="type">Tipe Work Order</label>
	  				<select name="wo" id="type" class="form-control" required>
	  					<option value="">Pilih Salah Satu</option>
	  					<option value="Maintenance">Maintenance</option>
	  					<option value="Gangguan">Gangguan</option>
	  				</select>
	  			</div>
	  			<div class="mb-3">
	  				<label for="spbu">No Spbu</label>
	  				<input type="text" class="form-control" name="spbu" id="spbu" required>
	  			</div>
	  			<div class="mb-3">
	  				<label for="alamat">Alamat Spbu</label>
	  				<input type="text" class="form-control" name="alamat_spbu" id="alamat" required>
	  			</div>
	  			<div class="mb-3">
	  				<label for="tanggal">Tanggal Laporan</label>
	  				<input type="date" class="form-control" name="tanggal_laporan" id="tanggal" required>
	  			</div>
	  			<div class="mb-3">
	  				<label for="keterangan">Keterangan</label>
	  				<input type="text" class="form-control" name="keterangan" id="keterangan" required>
	  			</div>
	  			<div class="mb-3">
	  				<label for="photo">Eviden Laporan</label>
	  				<div class="input-group">
	  					<input type="file" class="form-control" id="photo" name="photo">
	  				</div>
	  			</div>
	  			<div class="mb-3">
	  				<button class="btn btn-primary">Save</button>
	  			</div>
	  		</form>
	  	</div>
	  </div>

<?php $__env->stopSection(); ?>

	  

<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webreport\resources\views\teknisi-add.blade.php ENDPATH**/ ?>